/*
*/
package ManejadorFacturas;
import BeansFactura.Factura;
import BeansFactura.Detalle;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.ArrayList;
/**
 *
 * @author alumno
 */
public class ManejadorFactura { // DECLARACION DE FACTURA Y METODO DE ENTRADA
    private ArrayList<Factura> Facturas; //LISTA CON TODAS LAS FACTURAS CARGADAS
    private Scanner ing; // METODOD DE INGRESO
    private Factura factura; // FACTURA UNITARIA

    public ManejadorFactura() { // INICIALIZACION DE LAS VARIABLES EN VALOR CERO
        this.Facturas = new ArrayList();
        ing=new Scanner(System.in);
        this.factura= new Factura();
    }
    
    private void ingresoEncabezado(){ // INGRESO DE DATOS DEL ENCABEZADO DE LA FACTURA
        String fecha;
        Date f;
        System.out.println("Ingrese el numero de factura");
        this.factura.getHeader().setNumero(ing.next());
        System.out.println("Ingrese el nombre del cliente");
        this.factura.getHeader().setNombre(ing.nextLine());
        System.out.println("Ingrese el NIT del cliente");
        this.factura.getHeader().setNit(ing.nextLine());
        System.out.println("Ingrese la fecha de compra -dd/MM/YYYY-");
        fecha=ing.nextLine();
        try {
            f=new SimpleDateFormat("dd/MM/YYYY").parse(fecha);
        } catch (ParseException ex) {
            Logger.getLogger(ManejadorFactura.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Ingrese la direccion del cliente");
        this.factura.getHeader().setDireccion(ing.nextLine());
}
    private void ingresoDetalle(){ // SE INGRESAN LOS BIENES QUE SE COMPRARAN
        Detalle detalle;
        detalle=new Detalle();
        System.out.println("Ingrese la cantidad");
        detalle.setCantidad(ing.nextInt());
        System.out.println("Ingrese la descripcion");
        detalle.setDescripcion(ing.nextLine());
        System.out.println("Ingrese el precio");
        detalle.setPrecio(ing.nextInt());
        this.factura.getCuerpo().add(detalle); // SE AÑADE EL LISTADO DE DETALLE AL CUERPO DE LA FACTURA
    }
    public void ingresoDescuento(){ // SE INGRESA EL DESCUENTO SI ES QUE HAY
         System.out.println("Ingrese el descuento a aplicar en al factura en porcentaje %");
         this.factura.setDescuento(ing.nextInt());
    }
    public void muestraTodo(){ // MUESTRA LOS DATOS CONTENIDOS EN FACTURA SELECCIONADA
        int foo;
        int op;
        foo=0;
        op=0;
        System.out.println("Ingrese el numero de factura a consultar");
        op=ing.nextInt();
        System.out.println("El numero de la factura es:"+Facturas.get(op).getHeader().getNumero());      
        System.out.println("El nombre del cliente es:"+Facturas.get(op).getHeader().getNombre());
        System.out.println("El numero de NIT del cliente es:"+Facturas.get(op).getHeader().getNit());
        System.out.println("La fecha de la factura es:"+Facturas.get(op).getHeader().getFecha());
        System.out.println("La direccion del cliente es:"+Facturas.get(op).getHeader().getDireccion());
        System.out.println("El numero de la factura es:"+(Facturas.get(op).getTotal()-Facturas.get(op).getDesc()-Facturas.get(op).IVA()));
    }
    public void menu(){ // MENU PRINCIPAL
        int op;
        op=0;
        System.out.println("1.Ingreso de factura\n2.Muestra\n");
        op=ing.nextInt();
        if(op==1){ 
            ingresoEncabezado();
            ingresoDescuento();
            do{
            ingresoDetalle();
            System.out.println("Desea continuar?\n1. Si\n7. No");
            op=ing.nextInt();
            }while(op!=7);
            this.Facturas.add(this.factura); // SE AÑADE LA FACTURA QUE SE ESTÁ TRABAJANDO AL FINAL DEL LISTADO DE FACTURAS
            this.factura= new Factura(); // SE REINICIA EL VALOR DE LA FACTURA ACTUAL
        }else if(op==2){
            muestraTodo();
        }else{
            System.out.println("SALIDA");
        }
    } 
}
