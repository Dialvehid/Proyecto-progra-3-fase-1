/*
*/
package ManejadorFacturas;
import BeansFactura.Factura;
import BeansFactura.Detalle;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.ArrayList;
/**
 *
 * @author alumno
 */
public class ManejadorFactura { // DECLARACION DE FACTURA Y METODO DE ENTRADA
    private ArrayList<Factura> Facturas; //LISTA CON TODAS LAS FACTURAS CARGADAS
    private Scanner ing; // METODOD DE INGRESO
    private Factura factura; // FACTURA UNITARIA

    public ManejadorFactura() { // INICIALIZACION DE LAS VARIABLES EN VALOR CERO
        this.Facturas = new ArrayList();
        ing=new Scanner(System.in);
        this.factura= new Factura();
    }
    
    public String tp(int x){ // BUSQUEDA DEL TIPO DE PAGO
        if(x==1){
            return "Efectivo";
        }else if(x==2){
            return "Deposito";
        }else if(x==3){
            return "Credito";
        }else{
            return "Error";
        }
    } 
    private void ingresoEncabezado(){ // INGRESO DE DATOS DEL ENCABEZADO DE LA FACTURA
        String fecha;
        Date f;
        System.out.println("Ingrese el numero de factura");
        this.factura.getHeader().setNumero(ing.next());
        System.out.println("Ingrese el nombre del cliente");
        this.factura.getHeader().setNombre(ing.next());
        System.out.println("Ingrese el NIT del cliente");
        this.factura.getHeader().setNit(ing.next());
        System.out.println("Ingrese la fecha de compra -dd/MM/YYYY-");
        fecha=ing.next();
        try {
            f=new SimpleDateFormat("dd/MM/YYYY").parse(fecha);
        } catch (ParseException ex) {
            Logger.getLogger(ManejadorFactura.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Ingrese la direccion del cliente"); // NO RECIBE ESPACIOS
        this.factura.getHeader().setDireccion(ing.next());
}
    private void ingresoDetalle(){ // SE INGRESAN LOS BIENES QUE SE COMPRARAN
        Detalle detalle;
        detalle=new Detalle();
        System.out.println("Ingrese la descripcion");
        detalle.setDescripcion(ing.next());
        System.out.println("Ingrese la cantidad");
        detalle.setCantidad(ing.nextInt());
        System.out.println("Ingrese el precio");
        detalle.setPrecio(ing.nextInt());
        this.factura.getCuerpo().add(detalle); // SE AÑADE EL LISTADO DE DETALLE AL CUERPO DE LA FACTURA
    }
    public void ingresoDescuento(){ // SE INGRESA EL DESCUENTO SI ES QUE HAY
         System.out.println("Ingrese el descuento a aplicar en al factura en porcentaje %");
         this.factura.setDescuento(ing.nextInt());
    }
    public void muestraTodo(){ // MUESTRA LOS DATOS CONTENIDOS EN FACTURA SELECCIONADA
        int foo;
        int op;
        foo=0;
        op=0;
        System.out.println("Ingrese el numero de factura a consultar");
        op=ing.nextInt();
        System.out.println("El numero de la factura es:"+Facturas.get(op).getHeader().getNumero());      
        System.out.println("El nombre del cliente es:"+Facturas.get(op).getHeader().getNombre());
        System.out.println("El numero de NIT del cliente es:"+Facturas.get(op).getHeader().getNit());
        System.out.println("La fecha de la factura es:"+Facturas.get(op).getHeader().getFecha());
        System.out.println("La direccion del cliente es:"+Facturas.get(op).getHeader().getDireccion());
        System.out.println("El valor de la factura es:"+(Facturas.get(op).getTotal()-Facturas.get(op).getDesc()-Facturas.get(op).IVA()));
        System.out.println("El pago de la factura fue:"+tp(Facturas.get(op).getTpago())); 
    }
    public void tipo_de_pago(){
        int op;
        op=0;
        do{
            System.out.println("Seleccione un metodo de pago: \n 1. Efectivo\n 2. Deposito\n 3. Credito \n7. Cancelar facturacion");
            op=ing.nextInt();
        if(op==7){
            this.factura=new Factura();// EN CASO DE QUERER CANCELAR, SE REINICIA EL VALOR DE LA FACTURA ACTUAL
        }else if(op==1||op==2||op==3){
            this.factura.setTpago(op);// EN CASO DE HABER ELEGIDO EXITOSAMENTE, SE INGRESA EL DATO AL ARREGLO DE FACTURAS
        }else{
            op=0;
        }
        }while(op==0);
    }
    public void menu(){ // MENU PRINCIPAL
        int op;
        do{
        op=0;
        System.out.println("1.Ingreso de factura\n2.Muestra\n7.SAlIR");
        op=ing.nextInt();
        if(op==1){ 
            ingresoEncabezado(); // SE INGRESAN DATOS DEL CLIENTE
            ingresoDescuento();// SE INGRESA EL DESCUENTO SI ES QUE APLICA
            System.out.println("Ingreso de porductos");
            do{
            ingresoDetalle(); // SE INGRESAN LOS BIENES A COMPRAR
            System.out.println("Desea continuar?\n1. Si\n7. No");
            op=ing.nextInt(); // CONTINUAR AGREGANDO PRODUCTOS
            }while(op!=7);
            
            tipo_de_pago(); // SE SELECCIONA EL METODO DE PAGO
            this.Facturas.add(this.factura); // SE AÑADE LA FACTURA QUE SE ESTÁ TRABAJANDO AL FINAL DEL LISTADO DE FACTURAS
            this.factura= new Factura(); // SE REINICIA EL VALOR DE LA FACTURA ACTUAL
            op=0;
        }else if(op==2){
            muestraTodo(); // SE MUESTRA EL VALOR DE UNA FACTURA
            
        }
        }while(op!=7);// SALIDA DE FACTURACION
    } 
}
