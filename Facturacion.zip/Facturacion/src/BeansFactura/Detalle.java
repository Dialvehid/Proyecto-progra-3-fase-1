
package BeansFactura;
/**
 *
 * @author DIALVEHID
 */
public class Detalle { // ESTRUCTURA DE LOS PRODUCTOS COMPRADOS
    private int cantidad; //CANTIDAD DE CADA PRODUCTO
    private String descripcion; //DESCRIPCION O NOMBRE DEL PRODUCTO
    private float precio; //EL PRECIO UNITARIO DEL PRODUCTO
    private float st; //SUBTOTAL DE LA FACTURA, TOTAL POR PRODUCTO

    public Detalle(int cantidad, String descripcion, float precio) { //ENTRADA
        this.cantidad = cantidad;
        this.descripcion = descripcion;
        this.precio = precio;
        this.st=subtotal();
    }
    public Detalle() { // CASO VACIO
        this.cantidad = 0;
        this.descripcion = "";
        this.precio = (float)0.0;
        this.st=subtotal();
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public float getSt() {
        return st;
    }

    public void setSt(float st) {
        this.st = st;
    }
    
    public float subtotal(){ // CALCULO DEL SUBTOTAL DEL PRODUCTO
    float foo;
    foo=0;
    foo=cantidad*precio;
    return foo;
}
    
    
}
