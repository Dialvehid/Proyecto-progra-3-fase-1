/*
 */
package BeansFactura;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author alumno
 */
public class Factura {
    private Encabezado header;
    private List<Detalle> cuerpo;
    private Integer descuento;
    private float total;
    private float desc;

    public Factura(Encabezado header, List<Detalle> cuerpo, Integer descuento) {// ENTRADA
        this.header = header;
        this.cuerpo = cuerpo;
        this.descuento = descuento;
        this.total=total();
        this.desc=descuen();
    }
    public Factura() {// CASO VACIO
        this.header = new Encabezado();
        this.cuerpo = new ArrayList<>();
        this.descuento = 0;
        this.total=0;
        this.desc=0;
    }

    public Encabezado getHeader() {
        return header;
    }

    public void setHeader(Encabezado header) {
        this.header = header;
    }

    public List<Detalle> getCuerpo() {
        return cuerpo;
    }

    public void setCuerpo(List<Detalle> cuerpo) {
        this.cuerpo = cuerpo;
    }

    public Integer getDescuento() {
        return descuento;
    }

    public void setDescuento(Integer descuento) {
        this.descuento = descuento;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public float getDesc() {
        return desc;
    }

    public void setDesc(float desc) {
        this.desc = desc;
    }
    
    public float total(){ //TOTAL DE LA FACTURA COMPUESTO POR LA SUMA DE LOS SUBDTOTALES DE CADA DETALLE
        float foo;
        foo=0;
        for(int i=0;i<this.cuerpo.size();i++){
            foo=foo+this.cuerpo.get(i).getSt();
        }
        return foo;
    }
    private float descuen(){ //SE CALCULA EL DESCUENTO SOBRE EL TOTAL DE LA FACTURA
      float foo;
      foo= 0;
      foo=this.total*(this.descuento/100);
        return foo;
    }
    public float IVA(){ // SE CALCULA IMPUESTO SOBRE TOTAL DE FACTURA
        float foo;
        foo=0;
        foo=this.total-this.desc;
        foo=foo*(12/100);
        return foo;
    }
}
